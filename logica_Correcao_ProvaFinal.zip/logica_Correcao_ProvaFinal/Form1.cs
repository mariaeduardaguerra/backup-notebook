﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace logica_Correcao_ProvaFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularKevin_Click(object sender, EventArgs e)
        {
            int celsius = int.Parse(txtValorCelsius.Text);
            float kelvin;

            kelvin = celsius + 273.15f;

            lblResultadoKelvin.Text = kelvin.ToString();
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void Limpar()
        {
            txtValorCelsius.Text = "";
            cbDiagonal1.Text = "";
            cbDiagonal2.Text = "";
        }

        private void btnCalcularArea_Click(object sender, EventArgs e)
        {
            AreaLosango();
        }

        private void AreaLosango()
        {
            float diagonal1 = float.Parse(cbDiagonal1.Text);
            float diagonal2 = float.Parse(cbDiagonal2.Text);
            float resultadoArea;

            resultadoArea = (diagonal1 * diagonal2) / 2;
        }

    }
}
