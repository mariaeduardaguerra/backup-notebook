<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOTOR.PHP revisão prova final 1 etapa</title>
</head>

<body>

    <form action="salvar_motor.php" method="post">

        <p>
            modelo: <input type="text" name="modelo">
        </p>
        <p>
            número série: <input type="text" name="numero_serie">
        </p>
        <p>
            potência: <input type="text" name="potencia">
        </p>
        <p>
            <button>enviar</button>
        </p>

    </form>

    <a href="listar_motores.php">listar motores</a>
    
</body>

</html>