<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="ISO-8859-1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>atividade 01</title>
</head>

<body>

    <h1>ol� mundo! 1</h1>
    <h1>ol� mundo! 2</h1>
    <h1>ol� mundo! 3</h1>
    <h1>ol� mundo! 4</h1>
    <h1>ol� mundo! 5</h1>

    <?php
    echo("ol�" . "ol�");
    ?>

</body>

</html>