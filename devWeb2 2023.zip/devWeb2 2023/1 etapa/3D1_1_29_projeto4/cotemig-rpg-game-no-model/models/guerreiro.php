<?php
    class Guerreiro extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Guerreiro", "personagem-03.png", $nickname, 1, 0, 0);
        }

    }
?>

