<?php
    class ElfoNegro extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Elfo Negro", "personagem-02.png", $nickname, 1, 0, 0);
        }

    }
?>

