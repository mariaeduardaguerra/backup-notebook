
<?php
    class ElfaBranca extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Elfa Branca", "personagem-05.png", $nickname, 1, 0, 0);
        }

    }
?>
