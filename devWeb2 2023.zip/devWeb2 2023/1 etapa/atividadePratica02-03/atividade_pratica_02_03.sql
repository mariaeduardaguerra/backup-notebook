create database devweb2;

use devweb2;

create table soma (
    id int auto_increment,
    numero01 float,
    numero02 float,
    resultado float,
    primary key(id)
);