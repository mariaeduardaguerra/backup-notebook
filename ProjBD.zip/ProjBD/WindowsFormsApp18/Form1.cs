﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ConexaoAluno bd = new ConexaoAluno();

        private void button1_Click(object sender, EventArgs e)
        {
            String inserir;
            int teste;
            String unidade = rdbBarroca.Checked ? "Barroca" : "Floresta";
            int serie = rdbSerie1.Checked ? 1 : rdbSerie2.Checked ? 2 : 3;
            String turma = cbxTurma.Text;

            if(txtNome.Text != "" && int.TryParse(txtIdade.Text, out teste))
            {
                inserir = String.Format("insert into alunos (nome, idade, unidade, serie, turma) values ('{0}', '{1}', '{2}', '{3}', '{4}')", txtNome.Text, txtIdade.Text, unidade, serie, turma);
                MessageBox.Show(inserir);
                bd.executarComandos(inserir);
                txtNome.Clear();
                txtIdade.Clear();
                rdbBarroca.Checked = false;
                rdbFloresta.Checked = false;
                rdbSerie1.Checked = false; 
                rdbSerie2.Checked = false;
                rdbSerie3.Checked = false;
                cbxTurma.Text = "";
                txtNome.Focus();

            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String excluir;
            if(txtNome.Text != "")
            {
                excluir = String.Format("delete from alunos where nome = '{0}'", txtNome.Text);
                bd.executarComandos(excluir);
            }
            else
            {
                MessageBox.Show("Informação inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String alterar;
            int teste;
            if(int.TryParse(txtIdade.Text, out teste))
            {
                alterar = String.Format("Update alunos set idade = '{0}' where nome = '{1}'", txtIdade.Text, txtNome.Text);
                bd.executarComandos(alterar);

            }
            else
            {
                MessageBox.Show("Informação inválida", "Confirmação ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String sel = "Select * from alunos order by nome";
            DataTable dt = bd.executarConsulta(sel);
            dt.AsDataView();
            dtgAluno.DataSource = dt;
            
        }

        private void dtgAluno_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }

        private void dtgAluno_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            
            //txtNome.Text = 
        }

        private void dtgAluno_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //txtNome.Clear();
            txtNome.Text = dtgAluno.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtIdade.Text = dtgAluno.Rows[e.RowIndex].Cells[2].Value.ToString();
            String unidade = dtgAluno.Rows[e.RowIndex].Cells[3].Value.ToString();
            if (unidade == "Barroca")
                rdbBarroca.Checked = true;
            else
                rdbFloresta.Checked = true;
            cbxTurma.Text = dtgAluno.Rows[e.RowIndex].Cells[4].Value.ToString();

        }
    }
}
