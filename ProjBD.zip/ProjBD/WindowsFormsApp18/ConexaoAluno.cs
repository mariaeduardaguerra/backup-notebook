﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace WindowsFormsApp18
{
    internal class ConexaoAluno
    {
        MySqlConnection con;

        public void ConectarBD()
        {
            try
            {
                //dados da conexão
                con = new MySqlConnection("Persist Security info= false; server = localhost;" + "database=escola;user=root;pwd=Abc123!@#;");
                //abre a conexao
                con.Open();
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void executarComandos(String sql)
        {
            try
            {
                ConectarBD();
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
        public DataTable executarConsulta(String sql)
        {
            try
            {
                ConectarBD();

                MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }
    }
}
