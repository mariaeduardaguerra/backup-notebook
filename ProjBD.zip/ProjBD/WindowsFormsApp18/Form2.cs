﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp18
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        ConexaoAluno bd = new ConexaoAluno();
        private void button1_Click(object sender, EventArgs e)
        {
            String nome = txtNome.Text;
            String cargo = txtCargo.Text;
            String salario = txtSalario.Text;
            String inserir = "";

            if (txtNome.Text != "" && txtCargo.Text != "" && txtSalario.Text != "")
            {
                inserir = String.Format("insert into funcionario (nome, cargo, salario) values ('{0}', '{1}', '{2}')", txtNome.Text, txtCargo.Text, txtSalario.Text);
                
                bd.executarComandos(inserir);
                txtNome.Clear();
                txtCargo.Clear();
                txtSalario.Clear();
                //o cursor vai estar posicionado nesta txt
                txtNome.Focus();

            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String excluir;
            if (txtNome.Text != "")
            {
                excluir = String.Format("delete from funcionario where nome = '{0}'", txtNome.Text);
                bd.executarComandos(excluir);
            }
            else
            {
                MessageBox.Show("Informação inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String alterar;
            int teste;
            if (txtNome.Text != "" && txtSalario.Text != "")
            {
                alterar = String.Format("Update funcionario set cargo = '{0}', salario ='{1}' where nome = '{2}'", txtCargo.Text, txtSalario.Text, txtNome.Text);
                bd.executarComandos(alterar);
                txtNome.Clear();
                txtCargo.Clear();
                txtSalario.Clear();
                //o cursor vai estar posicionado nesta txt
                txtNome.Focus();
            }
            else
            {
                MessageBox.Show("Informação inválida", "Confirmação ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String sel = "Select * from funcionario order by nome";
            DataTable dt = bd.executarConsulta(sel);
            dt.AsDataView();
            dtgFuncionario.DataSource = dt;
        }
    }
}
