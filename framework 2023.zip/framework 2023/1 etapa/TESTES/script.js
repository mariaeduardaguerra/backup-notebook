var menu = {};

function addItem() {
  var daySelect = document.getElementById("day-select");
  var itemInput = document.getElementById("item-input");
  var day = daySelect.value;
  var item = itemInput.value;

  if (menu[day]) {
    menu[day].push(item);
  } else {
    menu[day] = [item];
  }

  displayMenu();
  itemInput.value = "";
}

function deleteItem(day, index) {
  menu[day].splice(index, 1);
  displayMenu();
}

function displayMenu() {
  var menuList = document.getElementById("menu-list");
  menuList.innerHTML = "";

  for (var day in menu) {
    if (menu.hasOwnProperty(day)) {
      var items = menu[day];

      var listItem = document.createElement("li");
      var daySpan = document.createElement("span");
      daySpan.textContent = capitalize(day) + ": ";
      listItem.appendChild(daySpan);

      for (var i = 0; i < items.length; i++) {
        var itemSpan = document.createElement("span");
        itemSpan.textContent = items[i];

        var deleteButton = document.createElement("button");
        deleteButton.textContent = "Excluir";
        deleteButton.setAttribute("onclick", "deleteItem('" + day + "', " + i + ")");

        listItem.appendChild(itemSpan);
        listItem.appendChild(deleteButton);
      }

      menuList.appendChild(listItem);
    }
  }
}

function capitalize(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
