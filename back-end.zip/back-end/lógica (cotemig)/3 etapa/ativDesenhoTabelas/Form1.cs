﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ativDesenhoTabelas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompleta_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            for (int linha = 0; linha < 5; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    lblResultado.Text += " * ";
                }
                lblResultado.Text += "\n";
            }
        }

        private void btnUmaDiagonal_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            for (int linha = 0; linha < 5; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    if(linha == coluna)
                    {
                        lblResultado.Text += " * ";
                    }
                    else
                    {
                        lblResultado.Text += "   ";
                    }
                }
                lblResultado.Text += "\n";
            }
        }

        private void btnDuasDiagonais_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            for (int linha = 0; linha < 5; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    if (linha == coluna || (linha + coluna) == 4)
                    {
                        lblResultado.Text += " * ";
                    }
                    else
                    {
                        lblResultado.Text += "   ";
                    }
                }
                lblResultado.Text += "\n";
            }
        }

        private void btnMetade_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            for (int linha = 0; linha < 5; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    if (linha >= coluna)
                    {
                        lblResultado.Text += " * ";
                    }
                    else
                    {
                        lblResultado.Text += "   ";
                    }
                }
                lblResultado.Text += "\n";
            }
        }

        private void btnCruz_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            for (int linha = 0; linha < 5; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    if (linha == 2 || coluna == 2)
                    {
                        lblResultado.Text += " * ";
                    }
                    else
                    {
                        lblResultado.Text += "   ";
                    }
                }
                lblResultado.Text += "\n";
            }
        }
    }
}
