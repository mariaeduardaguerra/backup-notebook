﻿namespace ativDesenhoTabelas
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCompleta = new System.Windows.Forms.Button();
            this.btnCruz = new System.Windows.Forms.Button();
            this.btnMetade = new System.Windows.Forms.Button();
            this.btnDuasDiagonais = new System.Windows.Forms.Button();
            this.btnUmaDiagonal = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCompleta
            // 
            this.btnCompleta.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompleta.Location = new System.Drawing.Point(309, 38);
            this.btnCompleta.Name = "btnCompleta";
            this.btnCompleta.Size = new System.Drawing.Size(171, 32);
            this.btnCompleta.TabIndex = 0;
            this.btnCompleta.Text = "Completa";
            this.btnCompleta.UseVisualStyleBackColor = true;
            this.btnCompleta.Click += new System.EventHandler(this.btnCompleta_Click);
            // 
            // btnCruz
            // 
            this.btnCruz.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCruz.Location = new System.Drawing.Point(309, 295);
            this.btnCruz.Name = "btnCruz";
            this.btnCruz.Size = new System.Drawing.Size(171, 28);
            this.btnCruz.TabIndex = 1;
            this.btnCruz.Text = "Cruz (+)";
            this.btnCruz.UseVisualStyleBackColor = true;
            this.btnCruz.Click += new System.EventHandler(this.btnCruz_Click);
            // 
            // btnMetade
            // 
            this.btnMetade.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMetade.Location = new System.Drawing.Point(309, 235);
            this.btnMetade.Name = "btnMetade";
            this.btnMetade.Size = new System.Drawing.Size(171, 28);
            this.btnMetade.TabIndex = 2;
            this.btnMetade.Text = "Metade";
            this.btnMetade.UseVisualStyleBackColor = true;
            this.btnMetade.Click += new System.EventHandler(this.btnMetade_Click);
            // 
            // btnDuasDiagonais
            // 
            this.btnDuasDiagonais.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDuasDiagonais.Location = new System.Drawing.Point(309, 169);
            this.btnDuasDiagonais.Name = "btnDuasDiagonais";
            this.btnDuasDiagonais.Size = new System.Drawing.Size(171, 28);
            this.btnDuasDiagonais.TabIndex = 3;
            this.btnDuasDiagonais.Text = "Duas Diagonais";
            this.btnDuasDiagonais.UseVisualStyleBackColor = true;
            this.btnDuasDiagonais.Click += new System.EventHandler(this.btnDuasDiagonais_Click);
            // 
            // btnUmaDiagonal
            // 
            this.btnUmaDiagonal.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUmaDiagonal.Location = new System.Drawing.Point(309, 100);
            this.btnUmaDiagonal.Name = "btnUmaDiagonal";
            this.btnUmaDiagonal.Size = new System.Drawing.Size(171, 32);
            this.btnUmaDiagonal.TabIndex = 4;
            this.btnUmaDiagonal.Text = "Uma Diagonal";
            this.btnUmaDiagonal.UseVisualStyleBackColor = true;
            this.btnUmaDiagonal.Click += new System.EventHandler(this.btnUmaDiagonal_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.Red;
            this.lblResultado.Location = new System.Drawing.Point(161, 130);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 16);
            this.lblResultado.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(161, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Desenho em Tabelas";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(505, 355);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnUmaDiagonal);
            this.Controls.Add(this.btnDuasDiagonais);
            this.Controls.Add(this.btnMetade);
            this.Controls.Add(this.btnCruz);
            this.Controls.Add(this.btnCompleta);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCompleta;
        private System.Windows.Forms.Button btnCruz;
        private System.Windows.Forms.Button btnMetade;
        private System.Windows.Forms.Button btnDuasDiagonais;
        private System.Windows.Forms.Button btnUmaDiagonal;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label label1;
    }
}

