﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoBD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            String nome = txtHospede.Text;
            String cargo = txtDtEntrada.Text;
            String salario = txtDtSaida.Text;
            String inserir = "";

            if (txtHospede.Text != "" && txtDtEntrada.Text != "" && txtDtSaida.Text != "")
            {
                inserir = String.Format("insert into funcionario (nome, cargo, salario) values ('{0}', '{1}', '{2}')", txtHospede.Text, txtDtEntrada.Text, txtDtSaida.Text);

                bd.executarComandos(inserir);
                txtHospede.Clear();
                txtDtEntrada.Clear();
                txtDtSaida.Clear();
                //o cursor vai estar posicionado nesta txt
                txtHospede.Focus();

            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            String excluir;
            if (txtHospede.Text != "")
            {
                excluir = String.Format("delete from hospede where nome = '{0}'", txtHospede.Text);
                bd.executarComandos(excluir);
            }
            else
            {
                MessageBox.Show("Informação inválida!", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            String alterar;
            int teste;
            if (txtHospede.Text != "" && txtDtEntrada.Text != "")
            {
                alterar = String.Format("Update hospede set entrada = '{0}', saida ='{1}' where nome = '{2}'", txtDtSaida.Text, txtDtEntrada.Text, txtHospede.Text);
                bd.executarComandos(alterar);
                txtHospede.Clear();
                txtDtEntrada.Clear();
                txtDtSaida.Clear();
                //o cursor vai estar posicionado nesta txt
                txtHospede.Focus();
            }
            else
            {
                MessageBox.Show("Informação inválida", "Confirmação ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            String sel = "Select * from hospede order by nome";
            DataTable dt = bd.executarConsulta(sel);
            dt.AsDataView();
            dtgDados.DataSource = dt;
        }
    }
}
