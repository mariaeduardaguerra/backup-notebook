﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            int[,] mat = new int[5, 5];
            Random r = new Random();

            for (int linha = 0; linha < mat.GetLength(0); linha++)
            {
                for (int coluna = 0; coluna < mat.GetLength(0); coluna++)
                {
                    mat[linha, coluna] = r.Next(10, 100);
                }
            }
            //exibir os números
            for (int linha = 0; linha < mat.GetLength(0); linha++)
            {
                for (int coluna = 0; coluna < mat.GetLength(0); coluna++)
                {
                    lblResultadoCompleta.Text += mat[linha, coluna] + " ";
                }
                lblResultadoCompleta.Text += "\n";
            }

        
            for (int linha = 0; linha < mat.GetLength(0); linha++)
            {
                for (int coluna = 0; coluna < mat.GetLength(0); coluna++)
                {
                    if (linha == 3 && coluna == 4)
                        lblResultadoCompleta.Text += mat[linha, coluna] + " ";
                    else
                        lblResultadoCompleta.Text += "   ";
                }
                lblResultadoCompleta.Text += "\n";
            }
        }
    }
}
