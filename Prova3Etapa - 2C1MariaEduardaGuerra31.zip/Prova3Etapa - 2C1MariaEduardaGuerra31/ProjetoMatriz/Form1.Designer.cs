﻿namespace ProjetoMatriz
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResultadoCompleta = new System.Windows.Forms.Label();
            this.btnMostrarMatrizCompleta = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblResultadoCompleta
            // 
            this.lblResultadoCompleta.AutoSize = true;
            this.lblResultadoCompleta.ForeColor = System.Drawing.Color.Red;
            this.lblResultadoCompleta.Location = new System.Drawing.Point(377, 121);
            this.lblResultadoCompleta.Name = "lblResultadoCompleta";
            this.lblResultadoCompleta.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoCompleta.TabIndex = 0;
            // 
            // btnMostrarMatrizCompleta
            // 
            this.btnMostrarMatrizCompleta.Location = new System.Drawing.Point(288, 316);
            this.btnMostrarMatrizCompleta.Name = "btnMostrarMatrizCompleta";
            this.btnMostrarMatrizCompleta.Size = new System.Drawing.Size(215, 23);
            this.btnMostrarMatrizCompleta.TabIndex = 1;
            this.btnMostrarMatrizCompleta.Text = "Mostrar Matriz Completa e Posição";
            this.btnMostrarMatrizCompleta.UseVisualStyleBackColor = true;
            this.btnMostrarMatrizCompleta.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(346, 22);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(106, 20);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "Projeto Matriz";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnMostrarMatrizCompleta);
            this.Controls.Add(this.lblResultadoCompleta);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResultadoCompleta;
        private System.Windows.Forms.Button btnMostrarMatrizCompleta;
        private System.Windows.Forms.Label lblTitulo;
    }
}

