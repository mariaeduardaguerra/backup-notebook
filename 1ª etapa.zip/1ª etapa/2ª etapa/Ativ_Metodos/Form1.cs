﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ_Metodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float num1 = 2;
            float num2 = 4;
            float num3 = 5;

            label1.Text = Media(num1, num2, num3).ToString();

        }
        private float Soma(float n1, float n2, float n3)
        {
            return n1 + n2 + n3;
        }
        //Fazer um método que mostre a média de 3 números
        private float Media(float n1, float n2, float n3)
        {
            return Soma(n1, n2, n3) / 3;
        }
    }
}

