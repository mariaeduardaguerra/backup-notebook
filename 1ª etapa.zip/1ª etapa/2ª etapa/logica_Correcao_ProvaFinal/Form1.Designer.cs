﻿namespace logica_Correcao_ProvaFinal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResultadoArea = new System.Windows.Forms.Label();
            this.lblResultadoKelvin = new System.Windows.Forms.Label();
            this.btnLimpaCampos = new System.Windows.Forms.Button();
            this.btnCalcularArea = new System.Windows.Forms.Button();
            this.btnCalcularKevin = new System.Windows.Forms.Button();
            this.cbDiagonal2 = new System.Windows.Forms.ComboBox();
            this.cbDiagonal1 = new System.Windows.Forms.ComboBox();
            this.lblDiagonal2 = new System.Windows.Forms.Label();
            this.lblDiagonal1 = new System.Windows.Forms.Label();
            this.txtValorCelsius = new System.Windows.Forms.TextBox();
            this.lblValorCelsius = new System.Windows.Forms.Label();
            this.lblAreaLosango = new System.Windows.Forms.Label();
            this.lblConverterCelsius = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblResultadoArea
            // 
            this.lblResultadoArea.AutoSize = true;
            this.lblResultadoArea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblResultadoArea.Location = new System.Drawing.Point(500, 299);
            this.lblResultadoArea.Name = "lblResultadoArea";
            this.lblResultadoArea.Size = new System.Drawing.Size(32, 22);
            this.lblResultadoArea.TabIndex = 27;
            this.lblResultadoArea.Text = "- ";
            // 
            // lblResultadoKelvin
            // 
            this.lblResultadoKelvin.AutoSize = true;
            this.lblResultadoKelvin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblResultadoKelvin.Location = new System.Drawing.Point(126, 299);
            this.lblResultadoKelvin.Name = "lblResultadoKelvin";
            this.lblResultadoKelvin.Size = new System.Drawing.Size(32, 22);
            this.lblResultadoKelvin.TabIndex = 26;
            this.lblResultadoKelvin.Text = "- ";
            // 
            // btnLimpaCampos
            // 
            this.btnLimpaCampos.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpaCampos.Location = new System.Drawing.Point(324, 421);
            this.btnLimpaCampos.Name = "btnLimpaCampos";
            this.btnLimpaCampos.Size = new System.Drawing.Size(145, 23);
            this.btnLimpaCampos.TabIndex = 25;
            this.btnLimpaCampos.Text = "Limpa Campos";
            this.btnLimpaCampos.UseVisualStyleBackColor = true;
            this.btnLimpaCampos.Click += new System.EventHandler(this.btnLimpaCampos_Click);
            // 
            // btnCalcularArea
            // 
            this.btnCalcularArea.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularArea.Location = new System.Drawing.Point(504, 324);
            this.btnCalcularArea.Name = "btnCalcularArea";
            this.btnCalcularArea.Size = new System.Drawing.Size(123, 23);
            this.btnCalcularArea.TabIndex = 24;
            this.btnCalcularArea.Text = "Calcular Área";
            this.btnCalcularArea.UseVisualStyleBackColor = true;
            this.btnCalcularArea.Click += new System.EventHandler(this.btnCalcularArea_Click);
            // 
            // btnCalcularKevin
            // 
            this.btnCalcularKevin.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularKevin.Location = new System.Drawing.Point(130, 324);
            this.btnCalcularKevin.Name = "btnCalcularKevin";
            this.btnCalcularKevin.Size = new System.Drawing.Size(123, 23);
            this.btnCalcularKevin.TabIndex = 23;
            this.btnCalcularKevin.Text = "Calcular";
            this.btnCalcularKevin.UseVisualStyleBackColor = true;
            this.btnCalcularKevin.Click += new System.EventHandler(this.btnCalcularKevin_Click);
            // 
            // cbDiagonal2
            // 
            this.cbDiagonal2.FormattingEnabled = true;
            this.cbDiagonal2.Items.AddRange(new object[] {
            "2",
            "6",
            "8",
            "9"});
            this.cbDiagonal2.Location = new System.Drawing.Point(538, 251);
            this.cbDiagonal2.Name = "cbDiagonal2";
            this.cbDiagonal2.Size = new System.Drawing.Size(121, 30);
            this.cbDiagonal2.TabIndex = 22;
            // 
            // cbDiagonal1
            // 
            this.cbDiagonal1.FormattingEnabled = true;
            this.cbDiagonal1.Items.AddRange(new object[] {
            "2",
            "6",
            "8",
            "9"});
            this.cbDiagonal1.Location = new System.Drawing.Point(538, 214);
            this.cbDiagonal1.Name = "cbDiagonal1";
            this.cbDiagonal1.Size = new System.Drawing.Size(121, 30);
            this.cbDiagonal1.TabIndex = 21;
            // 
            // lblDiagonal2
            // 
            this.lblDiagonal2.AutoSize = true;
            this.lblDiagonal2.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiagonal2.ForeColor = System.Drawing.Color.White;
            this.lblDiagonal2.Location = new System.Drawing.Point(428, 257);
            this.lblDiagonal2.Name = "lblDiagonal2";
            this.lblDiagonal2.Size = new System.Drawing.Size(107, 17);
            this.lblDiagonal2.TabIndex = 20;
            this.lblDiagonal2.Text = "Diagonal 2:";
            // 
            // lblDiagonal1
            // 
            this.lblDiagonal1.AutoSize = true;
            this.lblDiagonal1.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiagonal1.ForeColor = System.Drawing.Color.White;
            this.lblDiagonal1.Location = new System.Drawing.Point(428, 221);
            this.lblDiagonal1.Name = "lblDiagonal1";
            this.lblDiagonal1.Size = new System.Drawing.Size(107, 17);
            this.lblDiagonal1.TabIndex = 19;
            this.lblDiagonal1.Text = "Diagonal 1:";
            // 
            // txtValorCelsius
            // 
            this.txtValorCelsius.Location = new System.Drawing.Point(212, 252);
            this.txtValorCelsius.Name = "txtValorCelsius";
            this.txtValorCelsius.Size = new System.Drawing.Size(100, 29);
            this.txtValorCelsius.TabIndex = 18;
            // 
            // lblValorCelsius
            // 
            this.lblValorCelsius.AutoSize = true;
            this.lblValorCelsius.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorCelsius.ForeColor = System.Drawing.Color.White;
            this.lblValorCelsius.Location = new System.Drawing.Point(45, 257);
            this.lblValorCelsius.Name = "lblValorCelsius";
            this.lblValorCelsius.Size = new System.Drawing.Size(161, 17);
            this.lblValorCelsius.TabIndex = 17;
            this.lblValorCelsius.Text = "Valor em Celsius:";
            // 
            // lblAreaLosango
            // 
            this.lblAreaLosango.AutoSize = true;
            this.lblAreaLosango.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAreaLosango.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblAreaLosango.Location = new System.Drawing.Point(491, 154);
            this.lblAreaLosango.Name = "lblAreaLosango";
            this.lblAreaLosango.Size = new System.Drawing.Size(158, 18);
            this.lblAreaLosango.TabIndex = 16;
            this.lblAreaLosango.Text = "Área do Losango";
            // 
            // lblConverterCelsius
            // 
            this.lblConverterCelsius.AutoSize = true;
            this.lblConverterCelsius.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConverterCelsius.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblConverterCelsius.Location = new System.Drawing.Point(45, 154);
            this.lblConverterCelsius.Name = "lblConverterCelsius";
            this.lblConverterCelsius.Size = new System.Drawing.Size(328, 18);
            this.lblConverterCelsius.TabIndex = 15;
            this.lblConverterCelsius.Text = "Converter de Celsius para Kelvin";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(263, 48);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(206, 31);
            this.lblTitulo.TabIndex = 14;
            this.lblTitulo.Text = "Atividade 01";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(705, 509);
            this.Controls.Add(this.lblResultadoArea);
            this.Controls.Add(this.lblResultadoKelvin);
            this.Controls.Add(this.btnLimpaCampos);
            this.Controls.Add(this.btnCalcularArea);
            this.Controls.Add(this.btnCalcularKevin);
            this.Controls.Add(this.cbDiagonal2);
            this.Controls.Add(this.cbDiagonal1);
            this.Controls.Add(this.lblDiagonal2);
            this.Controls.Add(this.lblDiagonal1);
            this.Controls.Add(this.txtValorCelsius);
            this.Controls.Add(this.lblValorCelsius);
            this.Controls.Add(this.lblAreaLosango);
            this.Controls.Add(this.lblConverterCelsius);
            this.Controls.Add(this.lblTitulo);
            this.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResultadoArea;
        private System.Windows.Forms.Label lblResultadoKelvin;
        private System.Windows.Forms.Button btnLimpaCampos;
        private System.Windows.Forms.Button btnCalcularArea;
        private System.Windows.Forms.Button btnCalcularKevin;
        private System.Windows.Forms.ComboBox cbDiagonal2;
        private System.Windows.Forms.ComboBox cbDiagonal1;
        private System.Windows.Forms.Label lblDiagonal2;
        private System.Windows.Forms.Label lblDiagonal1;
        private System.Windows.Forms.TextBox txtValorCelsius;
        private System.Windows.Forms.Label lblValorCelsius;
        private System.Windows.Forms.Label lblAreaLosango;
        private System.Windows.Forms.Label lblConverterCelsius;
        private System.Windows.Forms.Label lblTitulo;
    }
}

