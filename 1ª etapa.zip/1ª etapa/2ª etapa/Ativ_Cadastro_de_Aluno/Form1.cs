﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ_Cadastro_de_Aluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string Vazio(string vazio)
        {
            if (vazio == "")
            {

                return "Por favor, digite algo!";
            }
            else
            {
                return "";
            }
        }

        private int Matricula(string matricula)
        {
            int erro = 0;
            int num_matricula = int.Parse(matricula);
            if (num_matricula < 1000 || num_matricula > 9999)
            {
                lblErroMatricula.Text = "Por favor, digite um número de matrícula válido!\n";
                return erro += 1;
            }
            else
            {
                lblErroMatricula.Text = "";
                return 0;
            }
        }

        private int Curso(string turma, string matricula)
        {
            int erro = 0;
            int num_matricula = int.Parse(matricula);
            if (turma == "Administração" && num_matricula > 3000)
            {
                lblErroTurma.Text = "O curso não corresponde à matrícula!";
                return erro += 1;
            }
            if (turma == "Mecatrônica" && num_matricula < 3001 || num_matricula > 5000)
            {
                lblErroTurma.Text = "O curso não corresponde à matrícula!";
                return erro += 1;
            }
            if (turma == "Informática" && num_matricula < 5001 || num_matricula > 7000)
            {
                lblErroTurma.Text = "O curso não corresponde à matrícula!";
                return erro += 1;
            }
            if (turma == "Tecnologia da Informação" && num_matricula < 7001 || num_matricula > 9999)
            {
                lblErroTurma.Text = "O curso não corresponde à matrícula!";
                return erro += 1;
            }
            else
            {
                lblErroTurma.Text = "";
                return 0;
            }
        }

        private void Limpar()
        {
            lblErroTurma.Text = "";
            lblErroSexo.Text = "";
            lblErroMatricula.Text = "";
            lblErroNome.Text = "";
            txtMatricula.Text = "";
            txtNome.Text = "";
            txtObservacoes.Text = "";
            txtTurma.Text = "";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string turma = lblTurma.Text;
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int erro = 0;

            if (matricula == "")
            {
                erro += 1;
                lblErroMatricula.Text = Vazio(matricula);
            }
            else
            {
                erro += Matricula(matricula);
                erro += Curso(turma, matricula);
            }

            lblErroNome.Text = Vazio(nome);    
            lblErroTurma.Text += Vazio(turma);

            if (lblErroNome.Text != "")
            {
                erro += 1;
            }
            if (lblErroTurma.Text != "")
            {
                erro += 1;
            }



            if (erro == 0)
            {
                MessageBox.Show("Cadastro realizado com sucesso!");
                Limpar();
            }



        }
    }
}



