﻿namespace Ativ_Cadastro_de_Aluno
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.comboBoxSexo = new System.Windows.Forms.ComboBox();
            this.lblTurma = new System.Windows.Forms.Label();
            this.txtTurma = new System.Windows.Forms.TextBox();
            this.lblObservacoes = new System.Windows.Forms.Label();
            this.txtObservacoes = new System.Windows.Forms.TextBox();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.lblErroMatricula = new System.Windows.Forms.Label();
            this.lblErroNome = new System.Windows.Forms.Label();
            this.lblErroTurma = new System.Windows.Forms.Label();
            this.lblErroSexo = new System.Windows.Forms.Label();
            this.lblErroObservacoes = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(295, 33);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(209, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Cadastro de Aluno";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(121, 70);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(124, 95);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(143, 20);
            this.txtMatricula.TabIndex = 2;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(121, 145);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(82, 13);
            this.lblNome.TabIndex = 3;
            this.lblNome.Text = "Nome Completo";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(122, 171);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(597, 20);
            this.txtNome.TabIndex = 4;
            // 
            // lblSexo
            // 
            this.lblSexo.AutoSize = true;
            this.lblSexo.Location = new System.Drawing.Point(121, 221);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(31, 13);
            this.lblSexo.TabIndex = 5;
            this.lblSexo.Text = "Sexo";
            // 
            // comboBoxSexo
            // 
            this.comboBoxSexo.FormattingEnabled = true;
            this.comboBoxSexo.Items.AddRange(new object[] {
            "Feminino",
            "Masculino"});
            this.comboBoxSexo.Location = new System.Drawing.Point(122, 246);
            this.comboBoxSexo.Name = "comboBoxSexo";
            this.comboBoxSexo.Size = new System.Drawing.Size(240, 21);
            this.comboBoxSexo.TabIndex = 6;
            // 
            // lblTurma
            // 
            this.lblTurma.AutoSize = true;
            this.lblTurma.Location = new System.Drawing.Point(458, 221);
            this.lblTurma.Name = "lblTurma";
            this.lblTurma.Size = new System.Drawing.Size(37, 13);
            this.lblTurma.TabIndex = 7;
            this.lblTurma.Text = "Turma";
            // 
            // txtTurma
            // 
            this.txtTurma.Location = new System.Drawing.Point(461, 246);
            this.txtTurma.Name = "txtTurma";
            this.txtTurma.Size = new System.Drawing.Size(258, 20);
            this.txtTurma.TabIndex = 8;
            // 
            // lblObservacoes
            // 
            this.lblObservacoes.AutoSize = true;
            this.lblObservacoes.Location = new System.Drawing.Point(119, 294);
            this.lblObservacoes.Name = "lblObservacoes";
            this.lblObservacoes.Size = new System.Drawing.Size(70, 13);
            this.lblObservacoes.TabIndex = 9;
            this.lblObservacoes.Text = "Observações";
            // 
            // txtObservacoes
            // 
            this.txtObservacoes.Location = new System.Drawing.Point(124, 321);
            this.txtObservacoes.Multiline = true;
            this.txtObservacoes.Name = "txtObservacoes";
            this.txtObservacoes.Size = new System.Drawing.Size(597, 49);
            this.txtObservacoes.TabIndex = 10;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.Location = new System.Drawing.Point(368, 408);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(101, 30);
            this.btnCadastrar.TabIndex = 11;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = true;
//            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // lblErroMatricula
            // 
            this.lblErroMatricula.AutoSize = true;
            this.lblErroMatricula.Location = new System.Drawing.Point(178, 132);
            this.lblErroMatricula.Name = "lblErroMatricula";
            this.lblErroMatricula.Size = new System.Drawing.Size(0, 13);
            this.lblErroMatricula.TabIndex = 12;
            // 
            // lblErroNome
            // 
            this.lblErroNome.AutoSize = true;
            this.lblErroNome.Location = new System.Drawing.Point(393, 221);
            this.lblErroNome.Name = "lblErroNome";
            this.lblErroNome.Size = new System.Drawing.Size(0, 13);
            this.lblErroNome.TabIndex = 13;
            // 
            // lblErroTurma
            // 
            this.lblErroTurma.AutoSize = true;
            this.lblErroTurma.Location = new System.Drawing.Point(579, 294);
            this.lblErroTurma.Name = "lblErroTurma";
            this.lblErroTurma.Size = new System.Drawing.Size(0, 13);
            this.lblErroTurma.TabIndex = 14;
            // 
            // lblErroSexo
            // 
            this.lblErroSexo.AutoSize = true;
            this.lblErroSexo.Location = new System.Drawing.Point(215, 270);
            this.lblErroSexo.Name = "lblErroSexo";
            this.lblErroSexo.Size = new System.Drawing.Size(0, 13);
            this.lblErroSexo.TabIndex = 15;
            // 
            // lblErroObservacoes
            // 
            this.lblErroObservacoes.AutoSize = true;
            this.lblErroObservacoes.Location = new System.Drawing.Point(393, 373);
            this.lblErroObservacoes.Name = "lblErroObservacoes";
            this.lblErroObservacoes.Size = new System.Drawing.Size(0, 13);
            this.lblErroObservacoes.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 450);
            this.Controls.Add(this.lblErroObservacoes);
            this.Controls.Add(this.lblErroSexo);
            this.Controls.Add(this.lblErroTurma);
            this.Controls.Add(this.lblErroNome);
            this.Controls.Add(this.lblErroMatricula);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.txtObservacoes);
            this.Controls.Add(this.lblObservacoes);
            this.Controls.Add(this.txtTurma);
            this.Controls.Add(this.lblTurma);
            this.Controls.Add(this.comboBoxSexo);
            this.Controls.Add(this.lblSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.ComboBox comboBoxSexo;
        private System.Windows.Forms.Label lblTurma;
        private System.Windows.Forms.TextBox txtTurma;
        private System.Windows.Forms.Label lblObservacoes;
        private System.Windows.Forms.TextBox txtObservacoes;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.Label lblErroMatricula;
        private System.Windows.Forms.Label lblErroNome;
        private System.Windows.Forms.Label lblErroTurma;
        private System.Windows.Forms.Label lblErroSexo;
        private System.Windows.Forms.Label lblErroObservacoes;
    }
}

