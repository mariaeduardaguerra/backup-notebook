﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ_Metodos_Funcionarios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt01.Text);
            float num2 = float.Parse(txt02.Text);
            float num3 = float.Parse(txt03.Text);
            lblResultado.Text = MaiorSalario(num1, num2, num3).ToString();
        }

        private float MaiorSalario(float num1, float num2, float num3)
        {
           if (num1 > num2 && num1 > num3)
           {
                return num1;
           }
           else if (num2 > num1 && num2 > num3)
           {
                return num2;
           }
           else if (num3 > num1 && num3 > num2)
           {
                return num3;
           }
           else
           {
                return 0;
           }
        }
}
}
