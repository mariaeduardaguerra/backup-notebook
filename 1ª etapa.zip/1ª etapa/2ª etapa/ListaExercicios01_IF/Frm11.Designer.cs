﻿namespace ListaExercicios01_IF
{
    partial class Frm11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestar = new System.Windows.Forms.Button();
            this.txtCondPag = new System.Windows.Forms.TextBox();
            this.txtPrcProduto = new System.Windows.Forms.TextBox();
            this.lblCondPag = new System.Windows.Forms.Label();
            this.lblPrcProduto = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTestar
            // 
            this.btnTestar.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTestar.Location = new System.Drawing.Point(374, 320);
            this.btnTestar.Name = "btnTestar";
            this.btnTestar.Size = new System.Drawing.Size(114, 47);
            this.btnTestar.TabIndex = 22;
            this.btnTestar.Text = "Testar";
            this.btnTestar.UseVisualStyleBackColor = true;
            this.btnTestar.Click += new System.EventHandler(this.btnTestar_Click);
            // 
            // txtCondPag
            // 
            this.txtCondPag.Location = new System.Drawing.Point(363, 249);
            this.txtCondPag.Name = "txtCondPag";
            this.txtCondPag.Size = new System.Drawing.Size(151, 20);
            this.txtCondPag.TabIndex = 21;
            // 
            // txtPrcProduto
            // 
            this.txtPrcProduto.Location = new System.Drawing.Point(363, 165);
            this.txtPrcProduto.Name = "txtPrcProduto";
            this.txtPrcProduto.Size = new System.Drawing.Size(151, 20);
            this.txtPrcProduto.TabIndex = 20;
            // 
            // lblCondPag
            // 
            this.lblCondPag.AutoSize = true;
            this.lblCondPag.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCondPag.Location = new System.Drawing.Point(171, 249);
            this.lblCondPag.Name = "lblCondPag";
            this.lblCondPag.Size = new System.Drawing.Size(186, 16);
            this.lblCondPag.TabIndex = 19;
            this.lblCondPag.Text = "Condição de pagamento:";
            // 
            // lblPrcProduto
            // 
            this.lblPrcProduto.AutoSize = true;
            this.lblPrcProduto.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrcProduto.Location = new System.Drawing.Point(242, 166);
            this.lblPrcProduto.Name = "lblPrcProduto";
            this.lblPrcProduto.Size = new System.Drawing.Size(115, 16);
            this.lblPrcProduto.TabIndex = 18;
            this.lblPrcProduto.Text = "Preço Produto:";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Mongolian Baiti", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(327, 84);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(187, 29);
            this.lblTitulo.TabIndex = 17;
            this.lblTitulo.Text = "QUESTÃO 11";
            // 
            // Frm11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTestar);
            this.Controls.Add(this.txtCondPag);
            this.Controls.Add(this.txtPrcProduto);
            this.Controls.Add(this.lblCondPag);
            this.Controls.Add(this.lblPrcProduto);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Frm11";
            this.Text = "Frm11";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestar;
        private System.Windows.Forms.TextBox txtCondPag;
        private System.Windows.Forms.TextBox txtPrcProduto;
        private System.Windows.Forms.Label lblCondPag;
        private System.Windows.Forms.Label lblPrcProduto;
        private System.Windows.Forms.Label lblTitulo;
    }
}