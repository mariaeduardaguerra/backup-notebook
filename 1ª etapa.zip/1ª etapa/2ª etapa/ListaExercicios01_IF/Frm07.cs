﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm07 : Form
    {
        public Frm07()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float altura = float.Parse(txtAltura.Text);
            float peso = float.Parse(txtPeso.Text);       
            string sexo = txtSexo.Text;
            float resultadoF;
            float resultadoM;


            switch (sexo)
            {
                case "Feminino":
                    resultadoF= (peso * altura) - 44.7f;
                    MessageBox.Show("O seu peso ideal é " + resultadoF);
                    break;

                case "Masculino":
                    resultadoM = (peso * altura) - 58;
                    MessageBox.Show("O seu peso ideal é "+ resultadoM);
                    break;

                    default:
                      MessageBox.Show("Resposta Inválida!");
                    break;
            }


            
        }
    }
}
