﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Frm12 : Form
    {
        public Frm12()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            float nota = float.Parse(txtNota.Text);

            if (nota >= 90)
            {
                MessageBox.Show("Conceito 'A'");
            }
            else if (nota >= 75 && nota < 90)
            {
                MessageBox.Show("Conceito 'B'");
            }
            else if (nota >= 60 && nota < 75)
            {
                MessageBox.Show("Conceito 'C'");
            }
            else if (nota >= 40 && nota < 60)
            {
                MessageBox.Show("Conceito 'D'");
            }
            else
            {
                MessageBox.Show("Conceito 'E'");
            }
                 
        }
    }
}
