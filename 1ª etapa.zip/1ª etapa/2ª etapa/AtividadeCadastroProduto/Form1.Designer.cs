﻿namespace AtividadeCadastroProduto
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.lblPrecoCusto = new System.Windows.Forms.Label();
            this.lblEstoqueMinimo = new System.Windows.Forms.Label();
            this.txtEstoqueMinimo = new System.Windows.Forms.TextBox();
            this.txtPrecoCusto = new System.Windows.Forms.TextBox();
            this.txtPrecoVenda = new System.Windows.Forms.TextBox();
            this.lblPrecoVenda = new System.Windows.Forms.Label();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.lblCategoria = new System.Windows.Forms.Label();
            this.txtAliquotaImposto = new System.Windows.Forms.TextBox();
            this.lblAliquotaImposto = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.lblErroDescricao = new System.Windows.Forms.Label();
            this.lblErroPrecoCusto = new System.Windows.Forms.Label();
            this.lblErroEstoqueMinimo = new System.Windows.Forms.Label();
            this.lblErroPrecoVenda = new System.Windows.Forms.Label();
            this.lblErroQuantidade = new System.Windows.Forms.Label();
            this.lblErroCategoria = new System.Windows.Forms.Label();
            this.lblErroAliquota = new System.Windows.Forms.Label();
            this.cmbCategoria = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(197, 21);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(229, 25);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Cadastro de Produto";
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricao.Location = new System.Drawing.Point(91, 76);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(68, 13);
            this.lblDescricao.TabIndex = 1;
            this.lblDescricao.Text = "Descrição:";
            this.lblDescricao.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(94, 92);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(451, 20);
            this.txtDescricao.TabIndex = 2;
            // 
            // lblPrecoCusto
            // 
            this.lblPrecoCusto.AutoSize = true;
            this.lblPrecoCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoCusto.Location = new System.Drawing.Point(91, 146);
            this.lblPrecoCusto.Name = "lblPrecoCusto";
            this.lblPrecoCusto.Size = new System.Drawing.Size(97, 13);
            this.lblPrecoCusto.TabIndex = 3;
            this.lblPrecoCusto.Text = "Preço de custo:";
            // 
            // lblEstoqueMinimo
            // 
            this.lblEstoqueMinimo.AutoSize = true;
            this.lblEstoqueMinimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstoqueMinimo.Location = new System.Drawing.Point(361, 146);
            this.lblEstoqueMinimo.Name = "lblEstoqueMinimo";
            this.lblEstoqueMinimo.Size = new System.Drawing.Size(101, 13);
            this.lblEstoqueMinimo.TabIndex = 4;
            this.lblEstoqueMinimo.Text = "Estoque mínimo:";
            // 
            // txtEstoqueMinimo
            // 
            this.txtEstoqueMinimo.Location = new System.Drawing.Point(364, 162);
            this.txtEstoqueMinimo.Name = "txtEstoqueMinimo";
            this.txtEstoqueMinimo.Size = new System.Drawing.Size(181, 20);
            this.txtEstoqueMinimo.TabIndex = 6;
            // 
            // txtPrecoCusto
            // 
            this.txtPrecoCusto.Location = new System.Drawing.Point(94, 162);
            this.txtPrecoCusto.Name = "txtPrecoCusto";
            this.txtPrecoCusto.Size = new System.Drawing.Size(181, 20);
            this.txtPrecoCusto.TabIndex = 7;
            // 
            // txtPrecoVenda
            // 
            this.txtPrecoVenda.Location = new System.Drawing.Point(94, 233);
            this.txtPrecoVenda.Name = "txtPrecoVenda";
            this.txtPrecoVenda.Size = new System.Drawing.Size(181, 20);
            this.txtPrecoVenda.TabIndex = 9;
            // 
            // lblPrecoVenda
            // 
            this.lblPrecoVenda.AutoSize = true;
            this.lblPrecoVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoVenda.Location = new System.Drawing.Point(91, 217);
            this.lblPrecoVenda.Name = "lblPrecoVenda";
            this.lblPrecoVenda.Size = new System.Drawing.Size(101, 13);
            this.lblPrecoVenda.TabIndex = 8;
            this.lblPrecoVenda.Text = "Preço de venda:";
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(364, 233);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(181, 20);
            this.txtQuantidade.TabIndex = 11;
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(361, 217);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(76, 13);
            this.lblQuantidade.TabIndex = 10;
            this.lblQuantidade.Text = "Quantidade:";
            // 
            // lblCategoria
            // 
            this.lblCategoria.AutoSize = true;
            this.lblCategoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoria.Location = new System.Drawing.Point(91, 284);
            this.lblCategoria.Name = "lblCategoria";
            this.lblCategoria.Size = new System.Drawing.Size(162, 13);
            this.lblCategoria.TabIndex = 12;
            this.lblCategoria.Text = "Categoria: Alimento/Bebida";
            // 
            // txtAliquotaImposto
            // 
            this.txtAliquotaImposto.Location = new System.Drawing.Point(364, 300);
            this.txtAliquotaImposto.Name = "txtAliquotaImposto";
            this.txtAliquotaImposto.Size = new System.Drawing.Size(181, 20);
            this.txtAliquotaImposto.TabIndex = 15;
            // 
            // lblAliquotaImposto
            // 
            this.lblAliquotaImposto.AutoSize = true;
            this.lblAliquotaImposto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaImposto.Location = new System.Drawing.Point(361, 284);
            this.lblAliquotaImposto.Name = "lblAliquotaImposto";
            this.lblAliquotaImposto.Size = new System.Drawing.Size(146, 13);
            this.lblAliquotaImposto.TabIndex = 14;
            this.lblAliquotaImposto.Text = "Alíquota de Imposto (%):";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.Location = new System.Drawing.Point(281, 339);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(85, 27);
            this.btnEnviar.TabIndex = 16;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // lblErroDescricao
            // 
            this.lblErroDescricao.AutoSize = true;
            this.lblErroDescricao.Location = new System.Drawing.Point(101, 115);
            this.lblErroDescricao.Name = "lblErroDescricao";
            this.lblErroDescricao.Size = new System.Drawing.Size(0, 13);
            this.lblErroDescricao.TabIndex = 17;
            // 
            // lblErroPrecoCusto
            // 
            this.lblErroPrecoCusto.AutoSize = true;
            this.lblErroPrecoCusto.Location = new System.Drawing.Point(101, 185);
            this.lblErroPrecoCusto.Name = "lblErroPrecoCusto";
            this.lblErroPrecoCusto.Size = new System.Drawing.Size(0, 13);
            this.lblErroPrecoCusto.TabIndex = 18;
            // 
            // lblErroEstoqueMinimo
            // 
            this.lblErroEstoqueMinimo.AutoSize = true;
            this.lblErroEstoqueMinimo.Location = new System.Drawing.Point(366, 185);
            this.lblErroEstoqueMinimo.Name = "lblErroEstoqueMinimo";
            this.lblErroEstoqueMinimo.Size = new System.Drawing.Size(0, 13);
            this.lblErroEstoqueMinimo.TabIndex = 19;
            // 
            // lblErroPrecoVenda
            // 
            this.lblErroPrecoVenda.AutoSize = true;
            this.lblErroPrecoVenda.Location = new System.Drawing.Point(101, 256);
            this.lblErroPrecoVenda.Name = "lblErroPrecoVenda";
            this.lblErroPrecoVenda.Size = new System.Drawing.Size(0, 13);
            this.lblErroPrecoVenda.TabIndex = 20;
            // 
            // lblErroQuantidade
            // 
            this.lblErroQuantidade.AutoSize = true;
            this.lblErroQuantidade.Location = new System.Drawing.Point(366, 256);
            this.lblErroQuantidade.Name = "lblErroQuantidade";
            this.lblErroQuantidade.Size = new System.Drawing.Size(0, 13);
            this.lblErroQuantidade.TabIndex = 21;
            // 
            // lblErroCategoria
            // 
            this.lblErroCategoria.AutoSize = true;
            this.lblErroCategoria.Location = new System.Drawing.Point(101, 323);
            this.lblErroCategoria.Name = "lblErroCategoria";
            this.lblErroCategoria.Size = new System.Drawing.Size(0, 13);
            this.lblErroCategoria.TabIndex = 22;
            // 
            // lblErroAliquota
            // 
            this.lblErroAliquota.AutoSize = true;
            this.lblErroAliquota.Location = new System.Drawing.Point(366, 323);
            this.lblErroAliquota.Name = "lblErroAliquota";
            this.lblErroAliquota.Size = new System.Drawing.Size(0, 13);
            this.lblErroAliquota.TabIndex = 23;
            // 
            // cmbCategoria
            // 
            this.cmbCategoria.FormattingEnabled = true;
            this.cmbCategoria.Items.AddRange(new object[] {
            "",
            "Alimento",
            "Bebida"});
            this.cmbCategoria.Location = new System.Drawing.Point(94, 300);
            this.cmbCategoria.Name = "cmbCategoria";
            this.cmbCategoria.Size = new System.Drawing.Size(181, 21);
            this.cmbCategoria.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(602, 378);
            this.Controls.Add(this.cmbCategoria);
            this.Controls.Add(this.lblErroAliquota);
            this.Controls.Add(this.lblErroCategoria);
            this.Controls.Add(this.lblErroQuantidade);
            this.Controls.Add(this.lblErroPrecoVenda);
            this.Controls.Add(this.lblErroEstoqueMinimo);
            this.Controls.Add(this.lblErroPrecoCusto);
            this.Controls.Add(this.lblErroDescricao);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.txtAliquotaImposto);
            this.Controls.Add(this.lblAliquotaImposto);
            this.Controls.Add(this.lblCategoria);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.txtPrecoVenda);
            this.Controls.Add(this.lblPrecoVenda);
            this.Controls.Add(this.txtPrecoCusto);
            this.Controls.Add(this.txtEstoqueMinimo);
            this.Controls.Add(this.lblEstoqueMinimo);
            this.Controls.Add(this.lblPrecoCusto);
            this.Controls.Add(this.txtDescricao);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.Label lblPrecoCusto;
        private System.Windows.Forms.Label lblEstoqueMinimo;
        private System.Windows.Forms.TextBox txtEstoqueMinimo;
        private System.Windows.Forms.TextBox txtPrecoCusto;
        private System.Windows.Forms.TextBox txtPrecoVenda;
        private System.Windows.Forms.Label lblPrecoVenda;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblCategoria;
        private System.Windows.Forms.TextBox txtAliquotaImposto;
        private System.Windows.Forms.Label lblAliquotaImposto;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Label lblErroDescricao;
        private System.Windows.Forms.Label lblErroPrecoCusto;
        private System.Windows.Forms.Label lblErroEstoqueMinimo;
        private System.Windows.Forms.Label lblErroPrecoVenda;
        private System.Windows.Forms.Label lblErroQuantidade;
        private System.Windows.Forms.Label lblErroCategoria;
        private System.Windows.Forms.Label lblErroAliquota;
        private System.Windows.Forms.ComboBox cmbCategoria;
    }
}

