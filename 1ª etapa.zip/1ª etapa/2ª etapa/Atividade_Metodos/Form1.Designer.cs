﻿namespace Atividade_Metodos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSoma = new System.Windows.Forms.Label();
            this.btnSoma = new System.Windows.Forms.Button();
            this.lblMedia = new System.Windows.Forms.Label();
            this.btnMedia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSoma
            // 
            this.lblSoma.AutoSize = true;
            this.lblSoma.Location = new System.Drawing.Point(230, 46);
            this.lblSoma.Name = "lblSoma";
            this.lblSoma.Size = new System.Drawing.Size(0, 13);
            this.lblSoma.TabIndex = 0;
            this.lblSoma.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(174, 106);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(153, 23);
            this.btnSoma.TabIndex = 1;
            this.btnSoma.Text = "Mostrar Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // lblMedia
            // 
            this.lblMedia.AutoSize = true;
            this.lblMedia.Location = new System.Drawing.Point(230, 167);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(0, 13);
            this.lblMedia.TabIndex = 2;
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(174, 212);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(153, 23);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = "Mostrar Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 362);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.lblMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.lblSoma);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSoma;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.Button btnMedia;
    }
}

