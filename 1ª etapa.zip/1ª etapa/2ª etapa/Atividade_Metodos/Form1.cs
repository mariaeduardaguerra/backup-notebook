﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_Metodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = 2;
            float num2 = 4;
            float somaDeDois = Soma(3, 4);
            lblSoma.Text = Soma(num1, num2).ToString();
            MessageBox.Show(Soma(6, 5).ToString());
        }

        private float Soma(float n1, float n2)
        {
            return n1 = n2;
        }

        private float Media(float n1, float n2, float n3)
        {
            return (n1 + n2 + n3) / 3;
        }
    }
}
