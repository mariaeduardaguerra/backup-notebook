﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeClasses
{
    class Matematica
    {
        public void Triplo(int num)
        {
            int resultado = num * 3;
            MessageBox.Show("O triplo de " + num + " é: " + resultado);
        }

        public void Soma(int num01, int num02)
        {
            int resultado = num01 + num02;
            MessageBox.Show("A soma entre " + num01 + " e " + num02 + " é: " + resultado);
        }

        public void Quadrado(int num)
        {
            int resultado = num * num;
            MessageBox.Show("O quadrado de " + num + " é: " + resultado);

        }
    }
}
