﻿namespace AtividadeClasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTriplo = new System.Windows.Forms.Button();
            this.txtTriplo = new System.Windows.Forms.TextBox();
            this.lblTriplo = new System.Windows.Forms.Label();
            this.lblSoma = new System.Windows.Forms.Label();
            this.txtSomaNum01 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.lblQuadrado = new System.Windows.Forms.Label();
            this.txtQuadrado = new System.Windows.Forms.TextBox();
            this.btnQuadrado = new System.Windows.Forms.Button();
            this.txtSomaNum02 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnTriplo
            // 
            this.btnTriplo.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTriplo.Location = new System.Drawing.Point(223, 79);
            this.btnTriplo.Name = "btnTriplo";
            this.btnTriplo.Size = new System.Drawing.Size(75, 23);
            this.btnTriplo.TabIndex = 0;
            this.btnTriplo.Text = "Calcular";
            this.btnTriplo.UseVisualStyleBackColor = true;
            this.btnTriplo.Click += new System.EventHandler(this.btnTriplo_Click);
            // 
            // txtTriplo
            // 
            this.txtTriplo.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTriplo.Location = new System.Drawing.Point(211, 53);
            this.txtTriplo.Name = "txtTriplo";
            this.txtTriplo.Size = new System.Drawing.Size(100, 20);
            this.txtTriplo.TabIndex = 1;
            // 
            // lblTriplo
            // 
            this.lblTriplo.AutoSize = true;
            this.lblTriplo.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTriplo.Location = new System.Drawing.Point(231, 34);
            this.lblTriplo.Name = "lblTriplo";
            this.lblTriplo.Size = new System.Drawing.Size(57, 16);
            this.lblTriplo.TabIndex = 6;
            this.lblTriplo.Text = "Triplo:";
            // 
            // lblSoma
            // 
            this.lblSoma.AutoSize = true;
            this.lblSoma.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoma.Location = new System.Drawing.Point(231, 144);
            this.lblSoma.Name = "lblSoma";
            this.lblSoma.Size = new System.Drawing.Size(52, 16);
            this.lblSoma.TabIndex = 9;
            this.lblSoma.Text = "Soma:";
            // 
            // txtSomaNum01
            // 
            this.txtSomaNum01.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSomaNum01.Location = new System.Drawing.Point(141, 163);
            this.txtSomaNum01.Name = "txtSomaNum01";
            this.txtSomaNum01.Size = new System.Drawing.Size(100, 20);
            this.txtSomaNum01.TabIndex = 8;
            // 
            // btnSoma
            // 
            this.btnSoma.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoma.Location = new System.Drawing.Point(223, 189);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(75, 23);
            this.btnSoma.TabIndex = 7;
            this.btnSoma.Text = "Calcular";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // lblQuadrado
            // 
            this.lblQuadrado.AutoSize = true;
            this.lblQuadrado.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuadrado.Location = new System.Drawing.Point(220, 252);
            this.lblQuadrado.Name = "lblQuadrado";
            this.lblQuadrado.Size = new System.Drawing.Size(83, 16);
            this.lblQuadrado.TabIndex = 12;
            this.lblQuadrado.Text = "Quadrado:";
            // 
            // txtQuadrado
            // 
            this.txtQuadrado.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuadrado.Location = new System.Drawing.Point(211, 271);
            this.txtQuadrado.Name = "txtQuadrado";
            this.txtQuadrado.Size = new System.Drawing.Size(100, 20);
            this.txtQuadrado.TabIndex = 11;
            // 
            // btnQuadrado
            // 
            this.btnQuadrado.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuadrado.Location = new System.Drawing.Point(223, 297);
            this.btnQuadrado.Name = "btnQuadrado";
            this.btnQuadrado.Size = new System.Drawing.Size(75, 23);
            this.btnQuadrado.TabIndex = 10;
            this.btnQuadrado.Text = "Calcular";
            this.btnQuadrado.UseVisualStyleBackColor = true;
            this.btnQuadrado.Click += new System.EventHandler(this.btnQuadrado_Click);
            // 
            // txtSomaNum02
            // 
            this.txtSomaNum02.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSomaNum02.Location = new System.Drawing.Point(275, 163);
            this.txtSomaNum02.Name = "txtSomaNum02";
            this.txtSomaNum02.Size = new System.Drawing.Size(100, 20);
            this.txtSomaNum02.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(508, 377);
            this.Controls.Add(this.txtSomaNum02);
            this.Controls.Add(this.lblQuadrado);
            this.Controls.Add(this.txtQuadrado);
            this.Controls.Add(this.btnQuadrado);
            this.Controls.Add(this.lblSoma);
            this.Controls.Add(this.txtSomaNum01);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.lblTriplo);
            this.Controls.Add(this.txtTriplo);
            this.Controls.Add(this.btnTriplo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTriplo;
        private System.Windows.Forms.TextBox txtTriplo;
        private System.Windows.Forms.Label lblTriplo;
        private System.Windows.Forms.Label lblSoma;
        private System.Windows.Forms.TextBox txtSomaNum01;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Label lblQuadrado;
        private System.Windows.Forms.TextBox txtQuadrado;
        private System.Windows.Forms.Button btnQuadrado;
        private System.Windows.Forms.TextBox txtSomaNum02;
    }
}

