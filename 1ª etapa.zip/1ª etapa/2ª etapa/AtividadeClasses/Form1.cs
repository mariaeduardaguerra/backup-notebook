﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeClasses
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTriplo_Click(object sender, EventArgs e)
        {
            int numero = int.Parse(txtTriplo.Text); 
            Matematica mat = new Matematica();
            mat.Triplo(numero);
        }



        private void btnSoma_Click(object sender, EventArgs e)
        {
            int num01 = int.Parse(txtSomaNum01.Text);
            int num02 = int.Parse(txtSomaNum02.Text);
            Matematica mat = new Matematica();
            mat.Soma( num01, num02);
        }

        private void btnQuadrado_Click(object sender, EventArgs e)
        {
            int num = int.Parse(txtQuadrado.Text);
            Matematica mat = new Matematica();
            mat.Quadrado(num);
        }
    }
}
