﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_Decremento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWhile_Click(object sender, EventArgs e)
        {
            int vlr01 = int.Parse(txtValor01.Text);
            int vlr02 = int.Parse(txtValor02.Text);
            lblResultado.Text = "";
            MostrarWhile(vlr01, vlr02);         
        }

        private void MostrarWhile(int vlr01, int vlr02)
        {
            if (vlr01 > vlr02)
            {
                while(vlr01 >= vlr02)
                {
                    lblResultado.Text += vlr01 + "";
                    vlr01--;
                }
            }
            else
            {
                lblResultado.Text = "O Valor 01 deve ser maior que o Valor 02!";
            }
        }
        private void btnDoWhile_Click(object sender, EventArgs e)
        {
            int vlr01 = int.Parse(txtValor01.Text);
            int vlr02 = int.Parse(txtValor02.Text);
            lblResultado.Text = "";
            MostrarDoWhile(vlr01, vlr02);
        }

        private void MostrarDoWhile(int vlr01, int vlr02)
        {
            if (vlr01 > vlr02)
            {
                do
                {
                    lblResultado.Text += vlr01 + "";
                    vlr01--;
                } while (vlr01 >= vlr02);
            }
            else
            {
                lblResultado.Text = "O Valor 01 deve ser maior que o Valor 02!";
            }
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            int vlr01 = int.Parse(txtValor01.Text);
            int vlr02 = int.Parse(txtValor02.Text);
            MostrarFor(vlr01, vlr02);
        }

        private void MostrarFor(int vlr01, int vlr02)
        {
            if (vlr01 > vlr02)
            {
                for (int contador = vlr01; contador >= vlr02; contador--)
                {
                    lblResultado.Text += contador + "";
                }
            }
            else
            {
                lblResultado.Text = "O Valor 01 deve ser maior que o Valor 02!";
            }
        }
    }
}
