﻿namespace Atividade_Decremento
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnValor01 = new System.Windows.Forms.Label();
            this.txtValor01 = new System.Windows.Forms.TextBox();
            this.txtValor02 = new System.Windows.Forms.TextBox();
            this.lblValor02 = new System.Windows.Forms.Label();
            this.btnWhile = new System.Windows.Forms.Button();
            this.btnDoWhile = new System.Windows.Forms.Button();
            this.btnFor = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.blbTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnValor01
            // 
            this.btnValor01.AutoSize = true;
            this.btnValor01.ForeColor = System.Drawing.Color.White;
            this.btnValor01.Location = new System.Drawing.Point(72, 87);
            this.btnValor01.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnValor01.Name = "btnValor01";
            this.btnValor01.Size = new System.Drawing.Size(98, 18);
            this.btnValor01.TabIndex = 0;
            this.btnValor01.Text = "Valor 01:";
            // 
            // txtValor01
            // 
            this.txtValor01.BackColor = System.Drawing.Color.Black;
            this.txtValor01.ForeColor = System.Drawing.Color.White;
            this.txtValor01.Location = new System.Drawing.Point(75, 128);
            this.txtValor01.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtValor01.Name = "txtValor01";
            this.txtValor01.Size = new System.Drawing.Size(164, 26);
            this.txtValor01.TabIndex = 1;
            // 
            // txtValor02
            // 
            this.txtValor02.BackColor = System.Drawing.Color.Black;
            this.txtValor02.ForeColor = System.Drawing.Color.White;
            this.txtValor02.Location = new System.Drawing.Point(75, 251);
            this.txtValor02.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtValor02.Name = "txtValor02";
            this.txtValor02.Size = new System.Drawing.Size(164, 26);
            this.txtValor02.TabIndex = 3;
            // 
            // lblValor02
            // 
            this.lblValor02.AutoSize = true;
            this.lblValor02.ForeColor = System.Drawing.Color.White;
            this.lblValor02.Location = new System.Drawing.Point(72, 210);
            this.lblValor02.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblValor02.Name = "lblValor02";
            this.lblValor02.Size = new System.Drawing.Size(98, 18);
            this.lblValor02.TabIndex = 2;
            this.lblValor02.Text = "Valor 02:";
            // 
            // btnWhile
            // 
            this.btnWhile.Location = new System.Drawing.Point(347, 87);
            this.btnWhile.Name = "btnWhile";
            this.btnWhile.Size = new System.Drawing.Size(182, 26);
            this.btnWhile.TabIndex = 4;
            this.btnWhile.Text = "Mostrar WHILE";
            this.btnWhile.UseVisualStyleBackColor = true;
            this.btnWhile.Click += new System.EventHandler(this.btnWhile_Click);
            // 
            // btnDoWhile
            // 
            this.btnDoWhile.Location = new System.Drawing.Point(347, 188);
            this.btnDoWhile.Name = "btnDoWhile";
            this.btnDoWhile.Size = new System.Drawing.Size(182, 26);
            this.btnDoWhile.TabIndex = 5;
            this.btnDoWhile.Text = "Mostrar DO-WHILE";
            this.btnDoWhile.UseVisualStyleBackColor = true;
            this.btnDoWhile.Click += new System.EventHandler(this.btnDoWhile_Click);
            // 
            // btnFor
            // 
            this.btnFor.Location = new System.Drawing.Point(347, 282);
            this.btnFor.Name = "btnFor";
            this.btnFor.Size = new System.Drawing.Size(182, 26);
            this.btnFor.TabIndex = 6;
            this.btnFor.Text = "Mostrar FOR";
            this.btnFor.UseVisualStyleBackColor = true;
            this.btnFor.Click += new System.EventHandler(this.btnFor_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.ForeColor = System.Drawing.Color.Red;
            this.lblResultado.Location = new System.Drawing.Point(72, 348);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 18);
            this.lblResultado.TabIndex = 7;
            // 
            // blbTitulo
            // 
            this.blbTitulo.AutoSize = true;
            this.blbTitulo.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.blbTitulo.Location = new System.Drawing.Point(143, 29);
            this.blbTitulo.Name = "blbTitulo";
            this.blbTitulo.Size = new System.Drawing.Size(278, 18);
            this.blbTitulo.TabIndex = 8;
            this.blbTitulo.Text = "Insira valores entre 0 e 10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(551, 408);
            this.Controls.Add(this.blbTitulo);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnFor);
            this.Controls.Add(this.btnDoWhile);
            this.Controls.Add(this.btnWhile);
            this.Controls.Add(this.txtValor02);
            this.Controls.Add(this.lblValor02);
            this.Controls.Add(this.txtValor01);
            this.Controls.Add(this.btnValor01);
            this.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label btnValor01;
        private System.Windows.Forms.TextBox txtValor01;
        private System.Windows.Forms.TextBox txtValor02;
        private System.Windows.Forms.Label lblValor02;
        private System.Windows.Forms.Button btnWhile;
        private System.Windows.Forms.Button btnDoWhile;
        private System.Windows.Forms.Button btnFor;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label blbTitulo;
    }
}

