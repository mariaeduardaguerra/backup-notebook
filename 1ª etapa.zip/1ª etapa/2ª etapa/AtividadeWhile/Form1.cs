﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeWhile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnMultiplos_Click(object sender, EventArgs e)
        {    
            int cont = 0;

            while (cont <= 99)
            {
                if (cont % 3 == 0)
                {
                    MessageBox.Show("" + cont);
                }
                
                cont = cont + 1;
            }
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int valor = 100;

            while (valor <= 999)
            {
                MessageBox.Show("" + valor);

                valor = valor + 1;
            }
        }

        private void btnSequencia_Click(object sender, EventArgs e)
        {
            int valor = 10;    

            while (valor <= 50)
            {
                MessageBox.Show("Aluno " + (valor/10) + ": "  + valor);
     
                valor = valor + 10;
            }

        }
    }
}
