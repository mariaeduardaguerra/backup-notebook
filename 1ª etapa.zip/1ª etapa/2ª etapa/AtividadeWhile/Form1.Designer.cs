﻿namespace AtividadeWhile
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMultiplos = new System.Windows.Forms.Label();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.lblSequencia = new System.Windows.Forms.Label();
            this.lblResultadoMultiplos = new System.Windows.Forms.Label();
            this.lblResultadoNumeros = new System.Windows.Forms.Label();
            this.lblResultadoSequencia = new System.Windows.Forms.Label();
            this.btnMultiplos = new System.Windows.Forms.Button();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.btnSequencia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMultiplos
            // 
            this.lblMultiplos.AutoSize = true;
            this.lblMultiplos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultiplos.Location = new System.Drawing.Point(50, 79);
            this.lblMultiplos.Name = "lblMultiplos";
            this.lblMultiplos.Size = new System.Drawing.Size(280, 18);
            this.lblMultiplos.TabIndex = 0;
            this.lblMultiplos.Text = "Mostrar os múltiplos de 3 de 1 a 99:";
            this.lblMultiplos.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.Location = new System.Drawing.Point(50, 160);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(277, 18);
            this.lblNumeros.TabIndex = 1;
            this.lblNumeros.Text = "Mostrar os números de 100 a 1000:";
            // 
            // lblSequencia
            // 
            this.lblSequencia.AutoSize = true;
            this.lblSequencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSequencia.Location = new System.Drawing.Point(50, 238);
            this.lblSequencia.Name = "lblSequencia";
            this.lblSequencia.Size = new System.Drawing.Size(227, 18);
            this.lblSequencia.TabIndex = 2;
            this.lblSequencia.Text = "Mostrar na tela a sequência :";
            // 
            // lblResultadoMultiplos
            // 
            this.lblResultadoMultiplos.AutoSize = true;
            this.lblResultadoMultiplos.Location = new System.Drawing.Point(392, 83);
            this.lblResultadoMultiplos.Name = "lblResultadoMultiplos";
            this.lblResultadoMultiplos.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoMultiplos.TabIndex = 3;
            // 
            // lblResultadoNumeros
            // 
            this.lblResultadoNumeros.AutoSize = true;
            this.lblResultadoNumeros.Location = new System.Drawing.Point(392, 164);
            this.lblResultadoNumeros.Name = "lblResultadoNumeros";
            this.lblResultadoNumeros.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoNumeros.TabIndex = 4;
            // 
            // lblResultadoSequencia
            // 
            this.lblResultadoSequencia.AutoSize = true;
            this.lblResultadoSequencia.Location = new System.Drawing.Point(392, 237);
            this.lblResultadoSequencia.Name = "lblResultadoSequencia";
            this.lblResultadoSequencia.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoSequencia.TabIndex = 5;
            // 
            // btnMultiplos
            // 
            this.btnMultiplos.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplos.Location = new System.Drawing.Point(484, 79);
            this.btnMultiplos.Name = "btnMultiplos";
            this.btnMultiplos.Size = new System.Drawing.Size(75, 23);
            this.btnMultiplos.TabIndex = 6;
            this.btnMultiplos.Text = "Mostrar";
            this.btnMultiplos.UseVisualStyleBackColor = true;
            this.btnMultiplos.Click += new System.EventHandler(this.btnMultiplos_Click);
            // 
            // btnNumeros
            // 
            this.btnNumeros.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeros.Location = new System.Drawing.Point(484, 160);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(75, 23);
            this.btnNumeros.TabIndex = 7;
            this.btnNumeros.Text = "Mostrar";
            this.btnNumeros.UseVisualStyleBackColor = true;
            this.btnNumeros.Click += new System.EventHandler(this.btnNumeros_Click);
            // 
            // btnSequencia
            // 
            this.btnSequencia.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSequencia.Location = new System.Drawing.Point(484, 233);
            this.btnSequencia.Name = "btnSequencia";
            this.btnSequencia.Size = new System.Drawing.Size(75, 23);
            this.btnSequencia.TabIndex = 8;
            this.btnSequencia.Text = "Mostrar";
            this.btnSequencia.UseVisualStyleBackColor = true;
            this.btnSequencia.Click += new System.EventHandler(this.btnSequencia_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(669, 331);
            this.Controls.Add(this.btnSequencia);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.btnMultiplos);
            this.Controls.Add(this.lblResultadoSequencia);
            this.Controls.Add(this.lblResultadoNumeros);
            this.Controls.Add(this.lblResultadoMultiplos);
            this.Controls.Add(this.lblSequencia);
            this.Controls.Add(this.lblNumeros);
            this.Controls.Add(this.lblMultiplos);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMultiplos;
        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.Label lblSequencia;
        private System.Windows.Forms.Label lblResultadoMultiplos;
        private System.Windows.Forms.Label lblResultadoNumeros;
        private System.Windows.Forms.Label lblResultadoSequencia;
        private System.Windows.Forms.Button btnMultiplos;
        private System.Windows.Forms.Button btnNumeros;
        private System.Windows.Forms.Button btnSequencia;
    }
}

