﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsDdos
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em inteiro!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em texto!");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em decimal!");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou texto!");
        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em boleano!");
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em enviar!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em limpar!");
        }

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em formulário!");
        }
    }
}
