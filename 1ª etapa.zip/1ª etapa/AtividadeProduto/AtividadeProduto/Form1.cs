﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeProduto
{
    public partial class FrmProduto : Form
    {
        public FrmProduto()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            float produto = float.Parse(btnDesconto.Text);
            float desconto;

            produto - (valor * 0, 10);
        }
    }
}
