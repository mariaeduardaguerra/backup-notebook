﻿namespace AppCalculadoraOutraVez
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCalculadora));
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnSubtracao = new System.Windows.Forms.Button();
            this.btnmultiplicacao = new System.Windows.Forms.Button();
            this.btndivisao = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblN1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblN1.Location = new System.Drawing.Point(124, 81);
            this.lblN1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(78, 16);
            this.lblN1.TabIndex = 0;
            this.lblN1.Text = "Número 1";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblN2.Location = new System.Drawing.Point(124, 152);
            this.lblN2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(78, 16);
            this.lblN2.TabIndex = 1;
            this.lblN2.Text = "Número 2";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(80, 101);
            this.txtN1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(164, 25);
            this.txtN1.TabIndex = 2;
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(80, 172);
            this.txtN2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(164, 25);
            this.txtN2.TabIndex = 3;
            // 
            // btnSoma
            // 
            this.btnSoma.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSoma.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSoma.Location = new System.Drawing.Point(55, 220);
            this.btnSoma.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(73, 46);
            this.btnSoma.TabIndex = 4;
            this.btnSoma.Text = "+";
            this.btnSoma.UseVisualStyleBackColor = false;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnSubtracao
            // 
            this.btnSubtracao.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSubtracao.Location = new System.Drawing.Point(55, 284);
            this.btnSubtracao.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnSubtracao.Name = "btnSubtracao";
            this.btnSubtracao.Size = new System.Drawing.Size(73, 46);
            this.btnSubtracao.TabIndex = 5;
            this.btnSubtracao.Text = "-";
            this.btnSubtracao.UseVisualStyleBackColor = false;
            this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
            // 
            // btnmultiplicacao
            // 
            this.btnmultiplicacao.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnmultiplicacao.Location = new System.Drawing.Point(193, 220);
            this.btnmultiplicacao.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnmultiplicacao.Name = "btnmultiplicacao";
            this.btnmultiplicacao.Size = new System.Drawing.Size(73, 46);
            this.btnmultiplicacao.TabIndex = 6;
            this.btnmultiplicacao.Text = "*";
            this.btnmultiplicacao.UseVisualStyleBackColor = false;
            this.btnmultiplicacao.Click += new System.EventHandler(this.btnmultiplicacao_Click);
            // 
            // btndivisao
            // 
            this.btndivisao.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btndivisao.Location = new System.Drawing.Point(193, 284);
            this.btndivisao.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(73, 46);
            this.btndivisao.TabIndex = 7;
            this.btndivisao.Text = "/";
            this.btndivisao.UseVisualStyleBackColor = false;
            this.btndivisao.Click += new System.EventHandler(this.btndivisao_Click);
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(323, 425);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.btnmultiplicacao);
            this.Controls.Add(this.btnSubtracao);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "FrmCalculadora";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnSubtracao;
        private System.Windows.Forms.Button btnmultiplicacao;
        private System.Windows.Forms.Button btndivisao;
    }
}

