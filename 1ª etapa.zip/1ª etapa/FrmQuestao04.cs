﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimulado31MariaEduardaGuerra
{
    public partial class FrmQuestao04 : Form
    {
        public FrmQuestao04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float salarioMinimo = float.Parse(txtMinimo.Text);
            float salarioFuncionario = float.Parse(txtFuncionario.Text);
            float resultado;

            resultado = (salarioFuncionario / salarioMinimo);

            MessageBox.Show("O funcionário recebe " + resultado);
        }
    }
}
