using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace CadastroAlunos
{
    internal class ConexaoAluno
    {
        MySqlConnection con;

        // string de conexão
        public void ConectarBD()
        {
            try
            {
                // dados da conexão
                con = new MySqlConnection("Persist Security info= false;server = localhoast;"
                    + "database=escola;user = root;pwd=;");
                // abre a conexão
                con.Open();
            }
            catch (Exception)
            {
                throw;
            }
        }

        // comandos de Insert, Delete, Update

        public void executarComandos(string sql)
        {
            try
            {
                // conecto com o banco
                ConectarBD();
                // preparo a query
                MySqlCommand cmd = new MySqlCommand(sql, con)
                // executo a query
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        public DataTable executarConsulta(string sql)
        {
            try
            {
                ConectarBD();
                MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                return dt;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        
    }
}
