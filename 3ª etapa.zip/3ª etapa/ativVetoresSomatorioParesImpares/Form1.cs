﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ativVetoresSomatorioParesImpares
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] somaPar = new int[30];
        int[] somaImpar = new int[30];

        private void button1_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            // atribuir valores ao vetor
            for (int a = 1; a <= 30; a = a + 2)
            {
                if(somaPar[a] %2 == 0)
                {
                    somaPar[a] = a;
                }        
            }

            // mostrar os valores do vetor
            for (int a = 1; a <= 30; a = a + 2)
            {
                lblResultado.Text += "Pares [" + a + "] = " + somaPar[a] + "\n";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            // atribuir valores ao vetor
            for (int a = 0; a <= 30; a = a + 2)
            {
                if (somaImpar[a] % 2 == 0)
                {
                    somaImpar[a] = a;
                }
            }

            // mostrar os valores do vetor
            for (int a = 0; a <= 30; a = a + 2)
            {
                lblResultado.Text += "Ímpares [" + a + "] = " + somaImpar[a] + "\n";
            }
        }
    }
}
