﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade_repetição_combobox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cb01_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            int contador = 0;
            int limite = int.Parse(cb01.Text);

            while (contador <= limite)
            {
                lblResultado.Text += contador + "";
                contador++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb01.Text = "0";
            cb02.Text = "0";
        }
    }
}
