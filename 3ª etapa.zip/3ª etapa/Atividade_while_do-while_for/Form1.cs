﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_while_do_while_for
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            int contador = 0;
            while (contador <= 100)
            {
                lblResultadoWhile.Text += contador + "";
                contador += 10;
            }
        }

        private void btnMostrarDoWhile_Click(object sender, EventArgs e)
        {
            int contador = 0;
            do
            {
                lblResultadoDoWhile.Text += contador + "";
                contador += 10;
            } while (contador <= 100);
             
        }

        private void btnMostrarFor_Click(object sender, EventArgs e)
        {
            for (int contador = 0; contador <= 100; contador += 10)
            {
                lblResultadoFor.Text += contador + "";
            }
        }
    }
}
