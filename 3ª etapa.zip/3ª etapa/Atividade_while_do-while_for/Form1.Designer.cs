﻿namespace Atividade_while_do_while_for
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResultadoWhile = new System.Windows.Forms.Label();
            this.btnMostrarWhile = new System.Windows.Forms.Button();
            this.btnMostrarDoWhile = new System.Windows.Forms.Button();
            this.lblResultadoDoWhile = new System.Windows.Forms.Label();
            this.btnMostrarFor = new System.Windows.Forms.Button();
            this.lblResultadoFor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblResultadoWhile
            // 
            this.lblResultadoWhile.AutoSize = true;
            this.lblResultadoWhile.Location = new System.Drawing.Point(92, 60);
            this.lblResultadoWhile.Name = "lblResultadoWhile";
            this.lblResultadoWhile.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoWhile.TabIndex = 0;
            // 
            // btnMostrarWhile
            // 
            this.btnMostrarWhile.Location = new System.Drawing.Point(328, 55);
            this.btnMostrarWhile.Name = "btnMostrarWhile";
            this.btnMostrarWhile.Size = new System.Drawing.Size(120, 23);
            this.btnMostrarWhile.TabIndex = 1;
            this.btnMostrarWhile.Text = "Mostrar WHILE";
            this.btnMostrarWhile.UseVisualStyleBackColor = true;
            this.btnMostrarWhile.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // btnMostrarDoWhile
            // 
            this.btnMostrarDoWhile.Location = new System.Drawing.Point(327, 161);
            this.btnMostrarDoWhile.Name = "btnMostrarDoWhile";
            this.btnMostrarDoWhile.Size = new System.Drawing.Size(121, 23);
            this.btnMostrarDoWhile.TabIndex = 3;
            this.btnMostrarDoWhile.Text = "Mostrar DO-WHILE";
            this.btnMostrarDoWhile.UseVisualStyleBackColor = true;
            this.btnMostrarDoWhile.Click += new System.EventHandler(this.btnMostrarDoWhile_Click);
            // 
            // lblResultadoDoWhile
            // 
            this.lblResultadoDoWhile.AutoSize = true;
            this.lblResultadoDoWhile.Location = new System.Drawing.Point(91, 166);
            this.lblResultadoDoWhile.Name = "lblResultadoDoWhile";
            this.lblResultadoDoWhile.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoDoWhile.TabIndex = 2;
            // 
            // btnMostrarFor
            // 
            this.btnMostrarFor.Location = new System.Drawing.Point(327, 257);
            this.btnMostrarFor.Name = "btnMostrarFor";
            this.btnMostrarFor.Size = new System.Drawing.Size(121, 23);
            this.btnMostrarFor.TabIndex = 5;
            this.btnMostrarFor.Text = "Mostrar FOR";
            this.btnMostrarFor.UseVisualStyleBackColor = true;
            this.btnMostrarFor.Click += new System.EventHandler(this.btnMostrarFor_Click);
            // 
            // lblResultadoFor
            // 
            this.lblResultadoFor.AutoSize = true;
            this.lblResultadoFor.Location = new System.Drawing.Point(91, 262);
            this.lblResultadoFor.Name = "lblResultadoFor";
            this.lblResultadoFor.Size = new System.Drawing.Size(0, 13);
            this.lblResultadoFor.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 344);
            this.Controls.Add(this.btnMostrarFor);
            this.Controls.Add(this.lblResultadoFor);
            this.Controls.Add(this.btnMostrarDoWhile);
            this.Controls.Add(this.lblResultadoDoWhile);
            this.Controls.Add(this.btnMostrarWhile);
            this.Controls.Add(this.lblResultadoWhile);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResultadoWhile;
        private System.Windows.Forms.Button btnMostrarWhile;
        private System.Windows.Forms.Button btnMostrarDoWhile;
        private System.Windows.Forms.Label lblResultadoDoWhile;
        private System.Windows.Forms.Button btnMostrarFor;
        private System.Windows.Forms.Label lblResultadoFor;
    }
}

