﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ativ_resolvida_matrizes
{
    public partial class EntradaDados : Form
    {
        public EntradaDados()
        {
            InitializeComponent();
        }

        int[,] matrizNumeros = new int[3, 3];

        private void btnComecar_Click(object sender, EventArgs e)
        {
        
            // obtendo valores do array
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    String valor = Interaction.InputBox("Insira nove elementos e obtenha uma matriz 3X3", "Matrizes");
                    matrizNumeros[i, j] = int.Parse(valor);
                }
            }

            // mostrando os valores do array
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    lblResultado.Text += matrizNumeros[i, j] + " ";
                }
                lblResultado.Text += "\n";
            }
        }
    }
}
