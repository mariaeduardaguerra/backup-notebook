create database escola;
use escola;
create table alunos(
id int auto_increment primary key,
nome varchar(200),
idade varchar(50),
unidade varchar(50),
serie varchar(50),
turma varchar(50)
);