﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD__escola
{
    public partial class FrmEscola : Form
    {
        public FrmEscola()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void FrmEscola_Load(object sender, EventArgs e)
        {

        }

        // ConexaoAluno bd = new ConexaoAluno();

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string inserir;
            int teste;
            string unidade = rdbBarroca.Checked ? "Barroca" : "Floresta";
            int serie = rdbSerie1.Checked ? rdbSerie2.Checked ? 2 : 3;
            string turmka = cbxTurma.Text;

            if (txtNome.Text != "" && int.TryParse(txtIdade.Text,out teste))
            {
                inserir = string.Format("insert into alunos (nome, idade, Unidade, Serie, Turma)
                                        values ('{0}', '{1}', '{2}', '{3}', '{4}',)",
                                        txtNome.Text,txtIdade.Text,unidade,serie,turma);
                bd.executarComandos(inserir);
                txtNome.Clear();
                txtIdade.Clear();
                rdbBarroca.Checked = false;
                rdbFloresta.Checked = false;
                rdbSerie1.Checked = false;
                rdbSerie2.Checked = false;
                rdbSerie3.Checked = false;
                cbxTurma.Text = "";
                txtNome.Focus();
            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação"),
                                MessageButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string excluir;
            if (txtNome.Text != "")
            {
                excluir = string.Format("delete from alunos where nome = '{0}'", txtNome.Text);
                bd.executarComandos(excluir);
            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação"),
                                MessageButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            string alterar;
            int teste;
            if (int.TryParse(txtIdade.Text, out teste))
            {
                alterar = string.Format("update alunos set idade = '{0}' where nome = '{1}'";
                                         txtIdade.Text, txtNome.Text);
            }
            else
            {
                MessageBox.Show("Informação Inválida!", "Confirmação"),
                                MessageButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
