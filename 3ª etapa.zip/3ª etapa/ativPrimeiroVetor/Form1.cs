﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ativPrimeiroVetor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] numeros = new int[6];

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";

            // atribuir valores ao vetor
            for (int i = 0; i < 6; i++)
            {
                numeros[i] = i;
            }

            // mostrar os valores do vetor
            for (int i = 0; i < 6; i++)
            {
                lblResultado.Text += "Números [" + i + "] = " + numeros[i] + "\n";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        int[] pares = new int[6];

        private void btnPares_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";
                
            // atribuir valores ao vetor
            for (int a = 0; a <= 6; a = a + 2)
            {
                pares[a] = a;
            }

            // mostrar os valores do vetor
            for (int a = 0; a <= 6; a = a + 2)
            {
                lblResultado.Text += "Pares [" + a + "] = " + pares[a] + "\n";
            }
        }

        
    }
}
