﻿namespace atividade_sequencia
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.txtWhile = new System.Windows.Forms.TextBox();
            this.txtDoWhile = new System.Windows.Forms.TextBox();
            this.txtFor = new System.Windows.Forms.TextBox();
            this.lblWhile = new System.Windows.Forms.Label();
            this.lblDoWhile = new System.Windows.Forms.Label();
            this.lblFor = new System.Windows.Forms.Label();
            this.lblWhileResultado = new System.Windows.Forms.Label();
            this.lblDoWhileResultado = new System.Windows.Forms.Label();
            this.lblForResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblTitulo.Location = new System.Drawing.Point(148, 24);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(418, 18);
            this.lblTitulo.TabIndex = 17;
            this.lblTitulo.Text = "Sequência: 2, 4, 8, 16, 32, 64, 128 e 256";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.ForeColor = System.Drawing.Color.Red;
            this.lblResultado.Location = new System.Drawing.Point(172, 378);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 13);
            this.lblResultado.TabIndex = 16;
            // 
            // btnExecutar
            // 
            this.btnExecutar.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecutar.Location = new System.Drawing.Point(339, 413);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(102, 26);
            this.btnExecutar.TabIndex = 13;
            this.btnExecutar.Text = "Executar";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // txtWhile
            // 
            this.txtWhile.Location = new System.Drawing.Point(67, 80);
            this.txtWhile.Multiline = true;
            this.txtWhile.Name = "txtWhile";
            this.txtWhile.Size = new System.Drawing.Size(610, 80);
            this.txtWhile.TabIndex = 18;
            // 
            // txtDoWhile
            // 
            this.txtDoWhile.Location = new System.Drawing.Point(67, 188);
            this.txtDoWhile.Multiline = true;
            this.txtDoWhile.Name = "txtDoWhile";
            this.txtDoWhile.Size = new System.Drawing.Size(610, 80);
            this.txtDoWhile.TabIndex = 19;
            // 
            // txtFor
            // 
            this.txtFor.Location = new System.Drawing.Point(67, 295);
            this.txtFor.Multiline = true;
            this.txtFor.Name = "txtFor";
            this.txtFor.Size = new System.Drawing.Size(610, 80);
            this.txtFor.TabIndex = 20;
            // 
            // lblWhile
            // 
            this.lblWhile.AutoSize = true;
            this.lblWhile.BackColor = System.Drawing.Color.White;
            this.lblWhile.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhile.ForeColor = System.Drawing.Color.Black;
            this.lblWhile.Location = new System.Drawing.Point(73, 82);
            this.lblWhile.Name = "lblWhile";
            this.lblWhile.Size = new System.Drawing.Size(42, 16);
            this.lblWhile.TabIndex = 21;
            this.lblWhile.Text = "While";
            // 
            // lblDoWhile
            // 
            this.lblDoWhile.AutoSize = true;
            this.lblDoWhile.BackColor = System.Drawing.Color.White;
            this.lblDoWhile.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoWhile.ForeColor = System.Drawing.Color.Black;
            this.lblDoWhile.Location = new System.Drawing.Point(73, 190);
            this.lblDoWhile.Name = "lblDoWhile";
            this.lblDoWhile.Size = new System.Drawing.Size(63, 16);
            this.lblDoWhile.TabIndex = 22;
            this.lblDoWhile.Text = "Do-While";
            // 
            // lblFor
            // 
            this.lblFor.AutoSize = true;
            this.lblFor.BackColor = System.Drawing.Color.White;
            this.lblFor.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFor.ForeColor = System.Drawing.Color.Black;
            this.lblFor.Location = new System.Drawing.Point(73, 297);
            this.lblFor.Name = "lblFor";
            this.lblFor.Size = new System.Drawing.Size(28, 16);
            this.lblFor.TabIndex = 23;
            this.lblFor.Text = "For";
            // 
            // lblWhileResultado
            // 
            this.lblWhileResultado.AutoSize = true;
            this.lblWhileResultado.BackColor = System.Drawing.Color.White;
            this.lblWhileResultado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblWhileResultado.Location = new System.Drawing.Point(351, 114);
            this.lblWhileResultado.Name = "lblWhileResultado";
            this.lblWhileResultado.Size = new System.Drawing.Size(0, 13);
            this.lblWhileResultado.TabIndex = 24;
            // 
            // lblDoWhileResultado
            // 
            this.lblDoWhileResultado.AutoSize = true;
            this.lblDoWhileResultado.BackColor = System.Drawing.Color.White;
            this.lblDoWhileResultado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblDoWhileResultado.Location = new System.Drawing.Point(364, 226);
            this.lblDoWhileResultado.Name = "lblDoWhileResultado";
            this.lblDoWhileResultado.Size = new System.Drawing.Size(0, 13);
            this.lblDoWhileResultado.TabIndex = 25;
            // 
            // lblForResultado
            // 
            this.lblForResultado.AutoSize = true;
            this.lblForResultado.BackColor = System.Drawing.Color.White;
            this.lblForResultado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblForResultado.Location = new System.Drawing.Point(364, 326);
            this.lblForResultado.Name = "lblForResultado";
            this.lblForResultado.Size = new System.Drawing.Size(0, 13);
            this.lblForResultado.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(732, 466);
            this.Controls.Add(this.lblForResultado);
            this.Controls.Add(this.lblDoWhileResultado);
            this.Controls.Add(this.lblWhileResultado);
            this.Controls.Add(this.lblFor);
            this.Controls.Add(this.lblDoWhile);
            this.Controls.Add(this.lblWhile);
            this.Controls.Add(this.txtFor);
            this.Controls.Add(this.txtDoWhile);
            this.Controls.Add(this.txtWhile);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnExecutar);
            this.Name = "Form1";
            this.Text = "Form1";
//            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.TextBox txtWhile;
        private System.Windows.Forms.TextBox txtDoWhile;
        private System.Windows.Forms.TextBox txtFor;
        private System.Windows.Forms.Label lblWhile;
        private System.Windows.Forms.Label lblDoWhile;
        private System.Windows.Forms.Label lblFor;
        private System.Windows.Forms.Label lblWhileResultado;
        private System.Windows.Forms.Label lblDoWhileResultado;
        private System.Windows.Forms.Label lblForResultado;
    }
}

